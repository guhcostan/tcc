// Uma classe simples que imprime "Oi, mundo" na tela

public class Hello {

	// main(), procedimento principal da classe
	public static void main(String args[]) {
		// utilizando a classe System para imprimir em tela
		System.out.println("Oi, mundo");
	}
}
