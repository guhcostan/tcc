//TOTAL = 10 PTOS
public class ImovelResidencial extends Imovel{// 2 ptos

	private int nQuartos;// 1 pto
	
	public ImovelResidencial(String inscricao, int cep, int nQuartos) {// 2 ptos
		super(inscricao, cep);
		this.nQuartos = nQuartos;
	}

	@Override
	public double getValorAluguel() {// 5 ptos
		if(nQuartos < 3){
			return 800;
		}else{
			return 1200;
		}
	}

}
