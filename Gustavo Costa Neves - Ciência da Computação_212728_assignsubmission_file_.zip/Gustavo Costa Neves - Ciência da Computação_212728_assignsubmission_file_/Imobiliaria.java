//TOTAL = 15 PTOS
import java.awt.List;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Function;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntFunction;
import java.util.function.ToLongFunction;


public class Imobiliaria {

	public Imobiliaria(String nome, int cnpj) {// 1 pto
		this.nome = nome;
		this.cnpj = cnpj;
	}

	private String nome;// 2 ptos
	
	private ArrayList<Imovel> imoveis = new ArrayList<Imovel>();//Inicializar no construtor
	
	private int cnpj;

	public void cadastrarImovel(Imovel i) {// 9 ptos
		
		if(imoveis.size() < 30){// < 30
			imoveis.add(i);
		}else{
			throw new LimiteImoveisExcedido(nome);
		}
		
	}

	public void gerarRelatorio() {// 3 ptos
		
		imoveis.sort(new Comparator<Imovel>() {//O exercício pede a utilização da interface Comparable
			public int compare(Imovel i1, Imovel i2) {
				if(i1.getCep() == i2.getCep()){
					return 0;
				}
				return i1.getCep() > i2.getCep() ? 1 : -1;
			}
		});
		
		for(int x = 0; x < imoveis.size(); x++){
			System.out.println(imoveis.get(x).toString());
		}
	}
	
}
