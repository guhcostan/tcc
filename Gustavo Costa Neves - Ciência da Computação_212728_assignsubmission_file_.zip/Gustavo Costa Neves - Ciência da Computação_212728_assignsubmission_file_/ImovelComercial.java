//TOTAL = 10 PTOS
public class ImovelComercial extends Imovel {// 2 ptos
	
	private int tamanho;// 1 pto

	public ImovelComercial(String inscricao, int cep, int tamanho) {// 2 ptos
		super(inscricao, cep);
		this.tamanho = tamanho;
	}

	@Override
	public double getValorAluguel() {// 5 ptos
		if(tamanho < 100){//<=
			return 2000;
		}else{
			return 3500;
		}
	}
}
