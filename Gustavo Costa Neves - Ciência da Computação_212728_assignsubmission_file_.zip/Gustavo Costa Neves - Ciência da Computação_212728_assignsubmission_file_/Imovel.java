//TOTAL = 6 PTOS
public class Imovel {

	private String inscricaoMunicipal;// 1 pto
	
	private int cep;

	public Imovel(String inscricaoMunicipal, int cep) {// 1 pto
		this.inscricaoMunicipal = inscricaoMunicipal;
		this.cep = cep;
	}

	public String getInscricaoMunicipal() {//ok
		return inscricaoMunicipal;
	}

	public int getCep() {//ok
		return cep;
	}
	
	public double getValorAluguel() {//Erro: método abstrato
		return 0;
	}

	@Override
	public String toString(){// 4 ptos

		String dados = "\nInscrição Municipal:" + this.inscricaoMunicipal + "\nCEP:" + this.cep + "\nValor do Aluguel:" + this.getValorAluguel();
		return dados;
	}
}
